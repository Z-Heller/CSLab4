﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania4
{
    class FilePersonRepository : IPersonRepository
    {
        public void Add(Person personToAdd)
        {
            List<Person> osoby = this.GetAll();
            osoby.Add(personToAdd);

            using (var sw = new StreamWriter("persondb.json"))
            {
                sw.WriteLine(JsonConvert.SerializeObject(osoby));
            }

        }

        public int CountPersonOverYrs(int yearsFromCount)
        {
            List<Person> osoby = this.GetAll();
            int count = 0;

            for (int i =0; i<osoby.Count; i++)
            {
                int rok = int.Parse(osoby[i].Pesel.ElementAt(0) + osoby[i].Pesel.ElementAt(1).ToString());
                if (rok < DateTime.Now.Year % 100) rok += 2000;
                else rok += 1900;

                if (rok >= yearsFromCount) count++;
            }

            return count;
        }

        public List<Person> GetAll()
        {
            using var read = new StreamReader("persondb.json");
            String baza = read.ReadToEnd();
            List<Person> osoby = JsonConvert.DeserializeObject<List<Person>>(baza);
            return osoby;
        }

        public Person GetById(int id)
        {
            List<Person> osoby = this.GetAll();
            
            return osoby[id-1];
        }

        public void Remove(int id)
        {
            List<Person> osoby = this.GetAll();

            osoby.RemoveAt(id - 1);

            using (var sw = new StreamWriter("persondb.json"))
            {
                sw.WriteLine(JsonConvert.SerializeObject(osoby));
            }
        }

        public void Update(Person personToUpdate, Person newPersonData)
        {
            List<Person> osoby = this.GetAll();

            osoby[personToUpdate.Id-1] = newPersonData;

            using (var sw = new StreamWriter("persondb.json"))
            {
                sw.WriteLine(JsonConvert.SerializeObject(osoby));
            }

        }
    }
}
