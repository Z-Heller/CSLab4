﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Zadania4
{
    class Program
    {
        public static List<Dane> elementy = new List<Dane>();

        static void Main(string[] args)
        {
            ////ZAD 1

            //using (var sw = new StreamWriter("album.txt"))
            //{
            //    sw.WriteLine("117797");

            //}


            ////ZAD 2

            //using (var sr = new StreamReader("odczyt.txt"))
            //{
            //    var line = sr.ReadToEnd();
            //    Console.WriteLine(line);
            //}


            ////ZAD 3

            //int fem = 0;
            //int num;

            //using (var sr = new StreamReader("pesels.txt"))
            //{
            //    var line = sr.ReadLine();
            //    while (line != null)
            //    {
            //        num = line[9];
            //        if (num % 2 == 0) fem++;
            //        Console.WriteLine(line);
            //        line = sr.ReadLine();
            //    }
            //}

            //Console.WriteLine("\nIlość kobiet: " + fem);


            ////ZAD 4

            //using var read = new StreamReader("db.json");
            //String baza = read.ReadToEnd();
            //elementy = JsonConvert.DeserializeObject<List<Dane>>(baza);

            ////a)
            //Console.WriteLine("różnica populacji pomiędzy rokiem 1970 a 2000 dla Indii: ");

            //Dane r1 = Szukaj("IN", 1970);
            //Dane r2 = Szukaj("IN", 2000);

            //Console.Write(Double.Parse(r2.Value) - Double.Parse(r1.Value)) ;

            ////b)
            //Console.WriteLine("\n\nróżnica populacji pomiędzy rokiem 1965 a 2010 dla USA: ");

            //r1 = Szukaj("US", 1965);
            //r2 = Szukaj("US", 2010);

            //Console.Write(Double.Parse(r2.Value) - Double.Parse(r1.Value));

            ////c)
            //Console.WriteLine("\n\nróżnica populacji pomiędzy rokiem 1980 a 2018 dla Chin: ");

            //r1 = Szukaj("US", 1980);
            //r2 = Szukaj("US", 2018);

            //Console.Write(Double.Parse(r2.Value) - Double.Parse(r1.Value));

            ////d)
            //Console.WriteLine("\n\nWprowadź rok: ");
            //int rok = int.Parse(Console.ReadLine());

            //Console.WriteLine("Wprowadź id kraju: ");
            //String kraj = Console.ReadLine();

            //Console.WriteLine("\nZnaleziona populacja: "+Szukaj(kraj, rok).Value);

            ////e)
            //Console.WriteLine("\n\nWprowadź rok początkowy: ");
            //int rok1 = int.Parse(Console.ReadLine());

            //Console.WriteLine("Wprowadź rok końcowy: ");
            //int rok2 = int.Parse(Console.ReadLine());

            //Console.WriteLine("Wprowadź id kraju: ");
            //String kraj = Console.ReadLine();

            //Console.WriteLine("\nRóżnica populacji: " + (Double.Parse(Szukaj(kraj, rok2).Value)- Double.Parse(Szukaj(kraj, rok1).Value)));

            ////e)
            //Console.WriteLine("\n\nWprowadź rok : ");
            //int rok = int.Parse(Console.ReadLine());

            //Console.WriteLine("Wprowadź id kraju: ");
            //String kraj = Console.ReadLine();

            //Console.WriteLine("\nWzrost populacji: " + ((Double.Parse(Szukaj(kraj, rok).Value) - Double.Parse(Szukaj(kraj, (rok-1)).Value))/ (Double.Parse(Szukaj(kraj, rok-1).Value))*100)+"%");




            //ZAD 5
            FilePersonRepository FPR = new FilePersonRepository();

            Console.WriteLine("Wszystkie osoby w bazie:");
            List<Person> osoby = FPR.GetAll();

            for(int i=0; i<osoby.Count; i++)
            {
                Console.WriteLine("ID: " + osoby[i].Id + ", Imię: " + osoby[i].FirstName + ", Nazwisko: " + osoby[i].LastName + ", Pesel: " + osoby[i].Pesel);
            }

            Console.WriteLine("\nOsoba o ID = 2:");
            Person os = FPR.GetById(2);
            Console.WriteLine("ID: " + os.Id + ", Imię: " + os.FirstName + ", Nazwisko: " + os.LastName + ", Pesel: " + os.Pesel);

            Console.WriteLine("\nBaza po dodaniu osoby:");
            os = new Person(4, "Kamila", "Baran", "06231613527");
            FPR.Add(os);

            FPR = new FilePersonRepository();
            osoby = FPR.GetAll();

            for (int i = 0; i < osoby.Count; i++)
            {
                Console.WriteLine("ID: " + osoby[i].Id + ", Imię: " + osoby[i].FirstName + ", Nazwisko: " + osoby[i].LastName + ", Pesel: " + osoby[i].Pesel);
            }

            Console.WriteLine("\nBaza po zaktualizowaniu ostatniej osoby:");
            Person os2 = new Person(4, "Anna", "Baran", "06231613527");
            
            FPR.Update(os, os2);
            FPR = new FilePersonRepository();
            osoby = FPR.GetAll();

            for (int i = 0; i < osoby.Count; i++)
            {
                Console.WriteLine("ID: " + osoby[i].Id + ", Imię: " + osoby[i].FirstName + ", Nazwisko: " + osoby[i].LastName + ", Pesel: " + osoby[i].Pesel);
            }

            Console.WriteLine("\nBaza po usunięciu ostatniej osoby:");

            FPR.Remove(4);
            FPR = new FilePersonRepository();
            osoby = FPR.GetAll();

            for (int i = 0; i < osoby.Count; i++)
            {
                Console.WriteLine("ID: " + osoby[i].Id + ", Imię: " + osoby[i].FirstName + ", Nazwisko: " + osoby[i].LastName + ", Pesel: " + osoby[i].Pesel);
            }

            FPR = new FilePersonRepository();
            osoby = FPR.GetAll();

            Console.WriteLine("\nIlość osób urodzonych po roku 2000: "+FPR.CountPersonOverYrs(2000));


        }

        public static Dane Szukaj(String id, int rok)
        {
            Dane znaleziono = new Dane();
            for(int i=0; i<elementy.Count; i++)
            {
                if (elementy[i].Country.Id == id && elementy[i].Date == rok)
                {
                    znaleziono = elementy[i];
                }
                
            }
            return znaleziono;
        }

    }
}
