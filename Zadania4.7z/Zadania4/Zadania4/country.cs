﻿using System;

    public struct Country
    {
        public String Id;
        public String Value;
    };

