﻿using System;

    public struct Dane
    {
        public Indicator Indicator;
        public Country Country;
        public String Value;
        public String Decimal;
        public int Date;
};

