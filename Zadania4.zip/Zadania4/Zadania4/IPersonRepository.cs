﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania4
{
    interface IPersonRepository
    {
        List<Person> GetAll();
        Person GetById(int id);
        void Add(Person personToAdd);
        void Update(Person personToUpdate, Person newPersonData);
        void Remove(int id);

        int CountPersonOverYrs(int yearsFromCount);
    }
}
