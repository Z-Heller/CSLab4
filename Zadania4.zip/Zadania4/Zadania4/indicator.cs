﻿using System;

    public struct Indicator
    {
        public String Id;
        public String Value;
    };

