﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadania5
{
    public class Person : ICloneable
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public Person(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        public Person()
        {
        }

        public void Copy(Person os)
        {
            this.FirstName = os.FirstName;
            this.LastName = os.LastName;

        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
