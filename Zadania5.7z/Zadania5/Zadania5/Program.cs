﻿using System;

namespace Zadania5
{
    class Program
    {
        static void Dlugosc(String napis)
        {
            Console.WriteLine("Długość napisu: " + napis.Length);
        }

        static void ThrowRandom()
        {
            Random rand = new Random();

            int i = rand.Next(1, 4);

            if (i == 1) throw new MojWyjatek1("Wyjątek 1");
            if (i == 2) throw new MojWyjatek2("Wyjątek 2");
            if (i == 3) throw new MojWyjatek3("Wyjątek 3");
        }

        static void CanThrowException()
        {
            if (new Random().Next(5) == 0)
                throw new Exception();
        }


        static void Main(string[] args)
        {
            //ZAD 1
            Console.WriteLine("ZAD 1");
            Dlugosc("programowanie");

            //Dlugosc(null); System.NullReferenceException

            try
            {
                Dlugosc(null);
            }
            catch (NullReferenceException e)
            {
                Console.Write(e.StackTrace);
                //throw new NullReferenceException();
                //throw new Exception("Błąd", e);
            }

            //ZAD 2
            Console.WriteLine("\n\nZAD 2");

            try
            {
                ThrowRandom();
            }
            catch(MojWyjatek1 e1)
            {
                Console.WriteLine(e1);
            }
            catch (MojWyjatek2 e2)
            {
                Console.WriteLine(e2);
            }
            catch (MojWyjatek3 e3)
            {
                Console.WriteLine(e3);
            }

            //ZAD 3
            Console.WriteLine("\nZAD 3");

            try
            {
                ThrowRandom();
            }
            catch(Exception ex)
            {
                try
                {
                    Console.WriteLine(ex);
                    ThrowRandom();
                }
                catch (MojWyjatek1 e1)
                {
                    Console.WriteLine(e1);
                    if (ex.Message==e1.Message)
                    {
                        Console.WriteLine("Ten błąd mógł być obsłużony przez ten sam blok");
                    }
                    else Console.WriteLine("Ten błąd mógł być obsłużony przez inny blok");
                }
                catch (MojWyjatek2 e2)
                {
                    Console.WriteLine(e2);
                    if (ex.Message == e2.Message)
                    {
                        Console.WriteLine("Ten błąd mógł być obsłużony przez ten sam blok");
                    }
                    else Console.WriteLine("Ten błąd mógł być obsłużony przez inny blok");
                }
                catch (MojWyjatek3 e3)
                {
                    Console.WriteLine(e3);
                    if (ex.Message == e3.Message)
                    {
                        Console.WriteLine("Ten błąd mógł być obsłużony przez ten sam blok");
                    }
                    else Console.WriteLine("Ten błąd mógł być obsłużony przez inny blok");
                }

            }

            //ZAD 4
            Console.WriteLine("\nZAD 4");
            try
            {
                CanThrowException();
                CanThrowException();
                CanThrowException();
                CanThrowException();
                CanThrowException();
            }
            catch(Exception e)
            {
                String stack =e.StackTrace;
                stack.Trim();
                var result = stack.Substring(stack.Length - 3);
                Console.Write("Instrukcja, która spowodowała wyjątek: ");

                switch (result)
                {
                    case "117":
                        Console.Write("1");
                            break;
                    case "118":
                        Console.Write("2");
                            break;
                    case "119":
                        Console.Write("3");
                            break;
                    case "120":
                        Console.Write("4");
                            break;
                    case "121":
                        Console.Write("5");
                            break;

                }
            }

            //ZAD5
            Console.WriteLine("\n\nZAD 5");

            Person osoba1 = new Person("Adam", "Kowalski");
            Person osoba2 = new Person();
            osoba2.Copy(osoba1);

            Console.WriteLine("Imię: " + osoba2.FirstName + ", Nazwisko: " + osoba2.LastName);

            try
            {
                osoba2.Copy(null);
            }
            catch(NullReferenceException ex)
            {
                Console.WriteLine("Osoba nie może być parametrem null");
            }

            //ZAD6
            Console.WriteLine("\n\nZAD 6");
            Person osoba3 = new Person("Anna", "Nowak");
            Person osoba4 = new Person();
            osoba4 = (Person)osoba3.Clone();

            Console.WriteLine("Imię: " + osoba4.FirstName + ", Nazwisko: " + osoba4.LastName);

            try
            {
                Person osnull = null;
                osoba4 = (Person)osnull.Clone();
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine("Osoba nie może być parametrem null");
            }


        }

    }
}
